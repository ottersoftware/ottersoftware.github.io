#import <Cocoa/Cocoa.h>

@interface OTSColourView : NSView {

}

@end
