//
//  main.m
//  Animator Proxy - Creating Keyframe Animations
//
//  Created by Simon Wolf on 23/05/2010.
//  Copyright 2010 Otter Software Ltd. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
