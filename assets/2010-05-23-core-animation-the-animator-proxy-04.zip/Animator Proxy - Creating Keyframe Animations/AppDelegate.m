#import "AppDelegate.h"
#import <QuartzCore/QuartzCore.h>

@interface AppDelegate (Private)

- (NSPoint)newViewOrigin;
- (NSDictionary *)addAnimation:(CAAnimation *)newAnimation toView:(NSView *)aView forKey:(NSString *)aKey;
- (CAKeyframeAnimation *)keyframeAnimation;

@end


@implementation AppDelegate

@synthesize window;
@synthesize view;

- (IBAction)changeOrigin:(id)sender;
{
  [view setAnimations:nil];
  
  NSRect newFrame = [view frame];
  newFrame.origin = [self newViewOrigin];
  
  [view setAnimations:[self addAnimation:[self keyframeAnimation] toView:view forKey:@"frameOrigin"]];
  [[view animator] setFrame:newFrame];
}

@end

@implementation AppDelegate (Private)

- (NSPoint)newViewOrigin;
{
  CGFloat offset = 20.0f;
  
  NSPoint newOrigin = NSZeroPoint;
  newOrigin.y = [[window contentView] frame].size.height - [view frame].size.height - offset;
  
  if ([view frame].origin.x > offset)
    newOrigin.x = offset;
  else
    newOrigin.x = [[window contentView] frame].size.width - [view frame].size.width - offset;
  
  return newOrigin;
}

- (NSDictionary *)addAnimation:(CAAnimation *)newAnimation toView:(NSView *)aView forKey:(NSString *)aKey;
{
  NSMutableDictionary *animations = [NSMutableDictionary dictionary];
  [animations addEntriesFromDictionary:[aView animations]];
  [animations setObject:newAnimation forKey:aKey];
  return animations;
}

- (CAKeyframeAnimation *)keyframeAnimation;
{
  CGFloat midPoint = NSMidX([[window contentView] frame]) - ([view frame].size.width / 2.0f);
  
  CAKeyframeAnimation *animation = [CAKeyframeAnimation animation];
  [animation setDuration:3.0f];
  [animation setValues:[NSArray arrayWithObjects:
                        [NSValue valueWithPoint:NSMakePoint([view frame].origin.x, [view frame].origin.y)],
                        [NSValue valueWithPoint:NSMakePoint(midPoint, [view frame].origin.y)],
                        [NSValue valueWithPoint:NSMakePoint(midPoint, [view frame].origin.y)],
                        [NSValue valueWithPoint:[self newViewOrigin]],
                        nil]];
  [animation setKeyTimes:[NSArray arrayWithObjects:
                          [NSNumber numberWithFloat:0.0],
                          [NSNumber numberWithFloat:0.17],
                          [NSNumber numberWithFloat:0.67],
                          [NSNumber numberWithFloat:1.00],
                          nil]];
  [animation setTimingFunctions:[NSArray arrayWithObjects:
                                 [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionLinear],
                                 [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionLinear],
                                 [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseIn],
                                 nil]];
  return animation;
}

@end
