#import "AppDelegate.h"
#import <QuartzCore/QuartzCore.h>

@interface AppDelegate (Private)

- (NSPoint)newViewOrigin;
- (NSDictionary *)addAnimation:(CAAnimation *)newAnimation toView:(NSView *)aView forKey:(NSString *)aKey;
- (CAKeyframeAnimation *)keyframeAnimation;

@end


@implementation AppDelegate

@synthesize window;
@synthesize view;

- (IBAction)changeOrigin:(id)sender;
{
  [view setAnimations:nil];
  
  NSRect newFrame = [view frame];
  newFrame.origin = [self newViewOrigin];
  
  [view setAnimations:[self addAnimation:[self keyframeAnimation] toView:view forKey:@"frameOrigin"]];
  [[view animator] setFrame:newFrame];
}

@end

@implementation AppDelegate (Private)

- (NSPoint)newViewOrigin;
{
  CGFloat offset = 20.0f;
  
  NSPoint newOrigin = NSZeroPoint;
  
  if ([view frame].origin.x > offset) {
    newOrigin.x = offset;
    newOrigin.y = [[window contentView] frame].size.height - [view frame].size.height - offset;
  } else {
    newOrigin.x = [[window contentView] frame].size.width - [view frame].size.width - offset;
    newOrigin.y = offset;
  }
  
  return newOrigin;
}

- (NSDictionary *)addAnimation:(CAAnimation *)newAnimation toView:(NSView *)aView forKey:(NSString *)aKey;
{
  NSMutableDictionary *animations = [NSMutableDictionary dictionary];
  [animations addEntriesFromDictionary:[aView animations]];
  [animations setObject:newAnimation forKey:aKey];
  return animations;
}

- (CAKeyframeAnimation *)keyframeAnimation;
{
  CGPoint midPoint = CGPointMake(NSMidX([[window contentView] frame]) - ([view frame].size.width / 2.0f),
                                 NSMidY([[window contentView] frame]) - ([view frame].size.height / 2.0f));
  
  CGMutablePathRef path = CGPathCreateMutable();
  CGPathMoveToPoint(path, NULL, [view frame].origin.x, [view frame].origin.y);
  CGPathAddCurveToPoint(path, NULL, [view frame].origin.x, midPoint.y, [view frame].origin.x, midPoint.y, midPoint.x, midPoint.y);
  CGPathAddCurveToPoint(path, NULL, [self newViewOrigin].x, midPoint.y, [self newViewOrigin].x, midPoint.y, [self newViewOrigin].x, [self newViewOrigin].y);
  
  CAKeyframeAnimation *animation = [CAKeyframeAnimation animation];
  [animation setDuration:3.0f];
  [animation setPath:path];
  [animation setTimingFunctions:[NSArray arrayWithObjects:
                                 [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseIn],
                                 [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseOut],
                                 nil]];
  
  CFRelease(path);
  
  return animation;
}

@end
