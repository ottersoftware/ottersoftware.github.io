#import "AppDelegate.h"
#import <QuartzCore/QuartzCore.h>

@interface AppDelegate (Private)

- (NSPoint)newViewOrigin;
- (NSDictionary *)addAnimation:(CAAnimation *)newAnimation toView:(NSView *)aView forKey:(NSString *)aKey;
- (CABasicAnimation *)basicAnimation;

@end


@implementation AppDelegate

@synthesize window;
@synthesize view;

- (IBAction)changeOrigin:(id)sender;
{
  [view setAnimations:nil];
  
  NSRect newFrame = [view frame];
  newFrame.origin = [self newViewOrigin];
  
  [view setAnimations:[self addAnimation:[self basicAnimation] toView:view forKey:@"frameOrigin"]];
  [[view animator] setFrame:newFrame];
}

@end

@implementation AppDelegate (Private)

- (NSPoint)newViewOrigin;
{
  CGFloat offset = 20.0f;
  
  NSPoint newOrigin = NSZeroPoint;
  newOrigin.y = [[window contentView] frame].size.height - [view frame].size.height - offset;
  
  if ([view frame].origin.x > offset)
    newOrigin.x = offset;
  else
    newOrigin.x = [[window contentView] frame].size.width - [view frame].size.width - offset;
  
  return newOrigin;
}

- (NSDictionary *)addAnimation:(CAAnimation *)newAnimation toView:(NSView *)aView forKey:(NSString *)aKey;
{
  NSMutableDictionary *animations = [NSMutableDictionary dictionary];
  [animations addEntriesFromDictionary:[aView animations]];
  [animations setObject:newAnimation forKey:aKey];
  return animations;
}

- (CABasicAnimation *)basicAnimation;
{
  CABasicAnimation *animation = [CABasicAnimation animation];
  [animation setDuration:3.0f];
  [animation setTimingFunction:[CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut]];
  return animation;
}

@end
