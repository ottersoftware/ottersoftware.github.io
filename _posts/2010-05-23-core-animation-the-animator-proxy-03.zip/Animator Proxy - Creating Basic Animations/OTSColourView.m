#import "OTSColourView.h"

@implementation OTSColourView

- (void)drawRect:(NSRect)dirtyRect {
  NSBezierPath *bp = [NSBezierPath bezierPathWithRoundedRect:[self bounds] xRadius:5.0f yRadius:5.0f];
  [[NSColor colorWithCalibratedRed:0.0f green:0.6f blue:0.0f alpha:1.0f] set];
  [bp fill];
}

@end
