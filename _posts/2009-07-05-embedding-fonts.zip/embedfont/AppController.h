//
//  AppController.h
//  font_test
//
//  Created by Simon Wolf on 05/07/2009.
//  Copyright 2009 Otter Software Ltd. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface AppController : NSObject {
    IBOutlet NSTextField * fontDemo;
}

@end
