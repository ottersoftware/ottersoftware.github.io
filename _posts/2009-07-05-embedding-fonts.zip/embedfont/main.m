//
//  main.m
//  embedfont
//
//  Created by Simon Wolf on 05/07/2009.
//  Copyright Otter Software Ltd 2009. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
