//
//  AppController.m
//  font_test
//
//  Created by Simon Wolf on 05/07/2009.
//  Copyright 2009 Otter Software Ltd. All rights reserved.
//

#import "AppController.h"

@implementation AppController

- (void)awakeFromNib
{
    [fontDemo setFont:[NSFont fontWithName:@"Crystal" size:36.0]];
    [fontDemo setStringValue:@"01:23:45:67:89"];
}

@end
