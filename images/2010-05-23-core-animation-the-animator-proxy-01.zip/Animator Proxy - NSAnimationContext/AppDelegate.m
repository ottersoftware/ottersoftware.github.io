#import "AppDelegate.h"

@interface AppDelegate (Private)

- (NSPoint)newOrigin;
- (NSSize)newSize;

@end


@implementation AppDelegate

@synthesize window;
@synthesize textField;

- (IBAction)performAnimation:(id)sender;
{
  [[textField animator] setFrameOrigin:[self newOrigin]];
  [[textField animator] setFrameSize:[self newSize]];
}

- (IBAction)performAnimationUsingContext:(id)sender;
{
  [[NSAnimationContext currentContext] setDuration:5.0f];
  [[textField animator] setFrameOrigin:[self newOrigin]];
  
  [NSAnimationContext beginGrouping];
  [[NSAnimationContext currentContext] setDuration:1.0f];
  [[textField animator] setFrameSize:[self newSize]];
  [NSAnimationContext endGrouping];
  
  [NSAnimationContext endGrouping];
}

@end


@implementation AppDelegate (Private)

- (NSPoint)newOrigin;
{
  CGFloat offset = 20.0f;
  
  NSPoint newOrigin = [textField frame].origin;

  if ([textField frame].origin.x == [[window contentView] frame].size.width - [textField frame].size.width - offset)
    newOrigin.x = offset;
  else
    newOrigin.x = [[window contentView] frame].size.width - [textField frame].size.width - offset;
  
  return newOrigin;
}

- (NSSize)newSize;
{
  NSSize newSize = [textField frame].size;
  if (newSize.height > 22.0)
    newSize.height = 22.0;
  else
    newSize.height = 44.0;
  
  return newSize;
}

@end
