#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject {
  NSWindow *window;
  NSTextField *textField;
}

@property (assign) IBOutlet NSWindow *window;
@property (assign) IBOutlet NSTextField *textField;

- (IBAction)performAnimation:(id)sender;
- (IBAction)performAnimationUsingContext:(id)sender;

@end
