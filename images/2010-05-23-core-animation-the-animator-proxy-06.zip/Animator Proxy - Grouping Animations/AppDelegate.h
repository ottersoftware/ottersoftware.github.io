#import <Cocoa/Cocoa.h>
#import "OTSColourView.h"

@interface AppDelegate : NSObject {
  NSWindow *window;
  OTSColourView *view;
}

@property (assign) IBOutlet NSWindow *window;
@property (assign) IBOutlet OTSColourView *view;

- (IBAction)changeOrigin:(id)sender;

@end
