#import "AppDelegate.h"
#import <QuartzCore/QuartzCore.h>

@interface AppDelegate (Private)

- (NSPoint)newViewOrigin;
- (NSSize)newViewSize;
- (CABasicAnimation *)originAnimation;
- (CABasicAnimation *)sizeAnimation;

@end


@implementation AppDelegate

@synthesize window;
@synthesize view;

- (IBAction)changeOrigin:(id)sender;
{
  CAAnimationGroup *group = [CAAnimationGroup animation];
  [group setAnimations:[NSArray arrayWithObjects:[self originAnimation], [self sizeAnimation], nil]];
  [group setDuration:4.5];
  
  NSDictionary *anims = [NSDictionary dictionaryWithObject:group forKey:@"groupedAnimation"];
  [view setAnimations:anims];

  [[view animator] setValue:nil forKey:@"groupedAnimation"];
}

@end


@implementation AppDelegate (Private)

- (NSPoint)newViewOrigin;
{
  CGFloat offset = 20.0f;
  
  NSPoint newOrigin = [view frame].origin;
  
  if ([view frame].origin.x > offset)
    newOrigin.x = offset;
  else
    newOrigin.x = [[window contentView] frame].size.width - [view frame].size.width - offset;
  
  return newOrigin;
}

- (NSSize)newViewSize;
{
  NSSize newSize = [view frame].size;
  
  if (newSize.height < 96.0f)
    newSize = NSMakeSize(163.0f, 96.0f);
  else
    newSize = NSMakeSize(81.5f, 48.0f);
  
  return newSize;
}

- (CABasicAnimation *)originAnimation;
{
  CABasicAnimation *animation = [CABasicAnimation animationWithKeyPath:@"frameOrigin"];
  [animation setDuration:3.0f];
  [animation setTimingFunction:[CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut]];
  [animation setFromValue:[NSValue valueWithPoint:[view frame].origin]];
  [animation setToValue:[NSValue valueWithPoint:[self newViewOrigin]]];
  return animation;
}

- (CABasicAnimation *)sizeAnimation;
{
  CABasicAnimation *animation = [CABasicAnimation animationWithKeyPath:@"frameSize"];
  [animation setDuration:3.0f];
  [animation setBeginTime:1.5f];
  [animation setTimingFunction:[CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionLinear]];
  [animation setFromValue:[NSValue valueWithSize:[view frame].size]];
  [animation setToValue:[NSValue valueWithSize:[self newViewSize]]];
  return animation;
}

@end
